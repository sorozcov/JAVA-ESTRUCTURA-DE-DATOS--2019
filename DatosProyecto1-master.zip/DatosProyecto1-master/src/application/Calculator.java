package application;
/**
 * Silvio Orozco 18282
 * Jose Castaneda 18161
 * Roberto Castillo 185546
 * 
 * Proyecto 1 	15/3/2019
 */

public interface Calculator {

	public String Calculate(String num1 , String num2 , String op);
	
}