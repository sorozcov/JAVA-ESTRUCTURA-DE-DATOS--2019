package application;

/**
 * Silvio Orozco 18282
 * Jose Castaneda 18161
 */
public interface Calculator {

	public int Calculate(int num1 , int num2 , String op);
	
}