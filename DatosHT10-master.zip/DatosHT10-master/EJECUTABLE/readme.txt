Para correr el programa en cmd tuvimos que hacer un jar
Se corre con 
java -jar DatosHT10.jar
Esperar un rato para la primera configuracion porque tarda por crear la base de datos.