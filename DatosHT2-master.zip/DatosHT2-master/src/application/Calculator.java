package application;


public interface Calculator {

	public int Calculate(int num1 , int num2 , String op);
	
}